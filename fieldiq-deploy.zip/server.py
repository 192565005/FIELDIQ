"""
FieldIQ — Gemini proxy backend
Endpoints: POST /api/ask, POST /api/diagnose
The Gemini API key stays server-side (read from env var GEMINI_API_KEY).
"""
import os
import logging
from typing import List, Optional, Dict, Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, HTTPException
from starlette.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
GEMINI_MODEL = "gemini-2.5-flash"
GEMINI_ENDPOINT = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("fieldiq")

app = FastAPI(title="FieldIQ API")
api = APIRouter(prefix="/api")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Part(BaseModel):
    text: Optional[str] = None


class Message(BaseModel):
    role: str
    parts: List[Part]


class AskPayload(BaseModel):
    system: str
    history: List[Message]


class DiagnosePayload(BaseModel):
    prompt: str
    mime_type: str
    image_b64: str


async def _call_gemini(contents: List[Dict[str, Any]]) -> str:
    async with httpx.AsyncClient(timeout=60.0) as cx:
        r = await cx.post(
            GEMINI_ENDPOINT,
            params={"key": GEMINI_API_KEY},
            headers={"Content-Type": "application/json"},
            json={"contents": contents},
        )
    if r.status_code != 200:
        logger.error("Gemini %s: %s", r.status_code, r.text[:300])
        raise HTTPException(status_code=502, detail="AI service unavailable")
    data = r.json()
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError):
        return "Sorry, no response."


@api.get("/")
async def health():
    return {"status": "ok", "service": "FieldIQ"}


@api.post("/ask")
async def ask(payload: AskPayload):
    contents = [{"role": "user", "parts": [{"text": payload.system}]}]
    for m in payload.history:
        parts = [{"text": p.text} for p in m.parts if p.text is not None]
        contents.append({"role": m.role, "parts": parts})
    return {"reply": await _call_gemini(contents)}


@api.post("/diagnose")
async def diagnose(payload: DiagnosePayload):
    contents = [{
        "parts": [
            {"inline_data": {"mime_type": payload.mime_type, "data": payload.image_b64}},
            {"text": payload.prompt},
        ]
    }]
    return {"reply": await _call_gemini(contents)}


app.include_router(api)
