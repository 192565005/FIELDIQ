# FieldIQ — Free Deployment Guide 🚀

Deploy your FieldIQ hackathon site to the public internet for **FREE**. No credit card, no subscription.

**Architecture:** Backend (Render) hides your Gemini API key. Frontend (Netlify) is a single static HTML file users actually visit.

```
[Visitor browser] → fieldiq.html on Netlify
                       ↓ calls /api/ask, /api/diagnose
                  Render backend (hides GEMINI_API_KEY) → Gemini API
```

---

## ✅ Files in this folder

| File | Purpose |
|---|---|
| `server.py` | The FastAPI backend (proxies Gemini, hides your key) |
| `requirements.txt` | Python dependencies for the backend |
| `render.yaml` | Tells Render how to run the backend |
| `Procfile` | Backup start command |
| `.env.example` | Reference for local testing only — DON'T commit a real `.env` |
| `fieldiq.html` | The frontend website (you'll upload this to Netlify) |

---

## STEP 1 — Push this folder to GitHub (one-time)

1. Go to https://github.com/new → name the repo `fieldiq` → **Public** → Create
2. On your computer, in this `deploy/` folder, run:
   ```bash
   git init
   git add .
   git commit -m "FieldIQ initial"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/fieldiq.git
   git push -u origin main
   ```

---

## STEP 2 — Deploy the backend to Render (free)

1. Go to https://render.com → **Sign up with GitHub** (free, no card)
2. Click **New +** → **Web Service**
3. Pick your `fieldiq` GitHub repo → **Connect**
4. Render auto-detects `render.yaml`. Just fill in:
   - **Name:** `fieldiq-backend` (or anything)
   - **Plan:** **Free**
5. Scroll to **Environment Variables** → click **Add** → add:
   - Key: `GEMINI_API_KEY`
   - Value: `AIzaSyA_PHg3Yik89gmysIZEgLzxoCJWs91t7TE` *(your real key from Google AI Studio)*
6. Click **Create Web Service**. Wait ~3–5 minutes for first build.
7. You'll get a URL like `https://fieldiq-backend.onrender.com`. **Copy it.**
8. Test: open `https://fieldiq-backend.onrender.com/api/` in browser. You should see `{"status":"ok","service":"FieldIQ"}`. ✅

> ⚠️ **Free-tier behavior:** Render sleeps your backend after 15 min idle. First request after sleep takes ~30 sec to wake. For your hackathon demo, **just hit the URL once 30 sec before judges arrive** and it'll be hot.

---

## STEP 3 — Point the HTML at your new backend

Open `fieldiq.html` in any text editor and find **line 473** (or search for `API_BASE`):

```javascript
const API_BASE = 'https://crop-diagnosis-1.preview.emergentagent.com';
```

Change it to your Render URL from Step 2:

```javascript
const API_BASE = 'https://fieldiq-backend.onrender.com';
```

Save the file.

---

## STEP 4 — Deploy the frontend to Netlify (free, no signup required)

Easiest method on planet earth:

1. Go to https://app.netlify.com/drop
2. **Drag and drop `fieldiq.html`** onto the page
3. Done. You get a public URL like `https://shiny-mango-1234.netlify.app/fieldiq.html`. 🎉

*(Optional)* Sign up for free to rename the URL to something nicer like `fieldiq-demo.netlify.app`.

---

## STEP 5 — Test the live site

1. Open your Netlify URL in an incognito window
2. Type a question in **Ask AI** → should reply
3. Upload a plant leaf photo in **Diagnose** → should give diagnosis
4. **Right-click → View Page Source** → search for `AIza` → **nothing found** ✅ Key is safe.

---

## 🆓 Free alternatives (if Render gives you trouble)

### Backend alternatives
| Host | Cost | Note |
|---|---|---|
| **Render** ⭐ | Free | Sleeps after 15 min idle |
| **Hugging Face Spaces** | Free | Never sleeps. Pick "Docker" SDK; needs 1 extra Dockerfile |
| **Fly.io** | Free 3 small VMs | Asks for credit card (won't charge) |
| **Vercel (Python)** | Free | Needs code restructure to serverless functions |

### Frontend alternatives
| Host | Cost | Note |
|---|---|---|
| **Netlify Drop** ⭐ | Free | Drag & drop, no signup |
| **Vercel** | Free | GitHub-connected |
| **GitHub Pages** | Free | Push to a repo, enable Pages in Settings |
| **Cloudflare Pages** | Free | Unlimited bandwidth |

---

## 🔧 Troubleshooting

**"Application error" or 500 on Render**
- Go to your Render service → **Logs** tab → look for the actual error
- Most common: forgot to set `GEMINI_API_KEY` env var. Add it in Render Dashboard → Environment.

**Frontend can't reach backend (CORS error in browser console)**
- Already handled — backend allows all origins. If you still see it, hard refresh (Ctrl+Shift+R).

**Render says "build failed: pip not found"**
- Make sure `render.yaml` is at the repo root (same level as `server.py`).

**Long cold start kills my demo**
- 30 sec before demo, open `https://your-backend.onrender.com/api/` in a tab. It wakes the server. It stays awake for 15 min after.

---

## 🧪 Test the backend locally first (optional)

```bash
cd deploy
pip install -r requirements.txt
cp .env.example .env
# edit .env and paste your GEMINI_API_KEY
uvicorn server:app --reload --port 8001
```

Then open `fieldiq.html` directly in your browser (after changing `API_BASE` to `http://localhost:8001`).

---

Built for hackathon speed. Total deploy time: **~10 minutes**. 🌾
